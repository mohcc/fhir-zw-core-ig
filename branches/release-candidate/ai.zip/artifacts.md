# Artifacts Summary - Zimbabwe Core IG v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Zimbabwe Patient](StructureDefinition-zw-patient.md) | Patient profile for Zimbabwe with support for citizenship information. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Patient Citizenship](StructureDefinition-citizenship.md) | The patient's legal status as citizen of a country. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Gender Value Set](ValueSet-ZimGender.md) | Administrative Gender |
| [MaritalStatus Value Set](ValueSet-ZimMaritalStatus.md) | Administrative Marital Status |
| [Zimbabwe Province Value Set](ValueSet-ZimProvince.md) | Subset of ISO 3166-2 codes representing Zimbabwe provinces |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Example Zimbabwean Patient](Patient-zw-patient-example.md) | A simple patient example with core demographics and identifiers. |
| [patient1](Patient-patient1.md) |  |

