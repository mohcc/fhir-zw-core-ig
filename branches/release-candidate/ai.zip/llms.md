# zw.fhir.ig.core#0.1.0: Zimbabwe Core IG

## Pages

* [Home](index.md)
* [About](about.md)
* [Downloads](downloads.md)
* [Artifacts Summary](artifacts.md)

## Resources

### ValueSets

* [Gender Value Set](ValueSet-ZimGender.md)
* [MaritalStatus Value Set](ValueSet-ZimMaritalStatus.md)
* [Zimbabwe Province Value Set](ValueSet-ZimProvince.md)

### Resource Profiles

* [Zimbabwe Patient](StructureDefinition-zw-patient.md)

### Extensions

* [Patient Citizenship](StructureDefinition-citizenship.md)

### ImplementationGuides

* [Zimbabwe Core IG](index.md)

### Examples

* [patient1 (Patient)](Patient-patient1.md)
* [zw-patient-example (Patient)](Patient-zw-patient-example.md)
