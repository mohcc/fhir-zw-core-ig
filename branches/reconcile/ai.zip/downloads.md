# Downloads - Zimbabwe Core IG v0.1.0

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

### Package

This is the technical package containing the artifacts in this Implementation Guide:

* [IG Package](package.tgz)
* Download the entire implementation guide for local browsing [here](full-ig.zip).

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (zw.fhir.ig.core.r4)](package.r4.tgz) and [R4B (zw.fhir.ig.core.r4b)](package.r4b.tgz) are available.

