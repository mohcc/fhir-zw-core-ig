# Home - Zimbabwe Core IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://mohcc.gov.zw/fhir/core/ImplementationGuide/zw.fhir.ig.core | *Version*:0.1.0 |
| Draft as of 2025-11-13 | *Computable Name*:ZWCore |

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration and practice purposes only. 

### Summary

This Implementation Guide provides the foundational FHIR specifications that define how health information systems in Zimbabwe should **structure, exchange, and interpret health data. It outlines the national standards, profiles, extensions, and data exchange requirements based on the HL7® FHIR® framework**, customized to meet Zimbabwe’s healthcare and interoperability needs. The guide serves as the core reference for developers, implementers, and policymakers to ensure consistent and interoperable digital health solutions across the country.

